# -*- coding: utf-8 -*-
# @Time : 2020/8/23 2:01
# @公众号 :Python自动化办公社区 
# @File : 22_最近很火的数据动图，怎么用Python做.py
# @Software: PyCharm
# @Description: 

- 30分钟教程链接
    - https://www.bilibili.com/video/BV1zi4y1t7YU
    - 30分钟