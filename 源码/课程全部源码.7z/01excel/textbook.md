- excel：
    - 文件.xlsx
        - sheet
            - 单元格：a1/a2/b3/c6
- xlrd
    - 读excel

- xlwt
    - 写excel

- xlutils
    - 设置单元格格式（选学）
    
- 统计3年2班学生总分
