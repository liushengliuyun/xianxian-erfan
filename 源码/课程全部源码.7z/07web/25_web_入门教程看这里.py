# -*- coding: utf-8 -*-
# @Time : 2020/8/23 2:16
# @公众号 :Python自动化办公社区 
# @File : 25_web_入门教程看这里.py
# @Software: PyCharm
# @Description:

# django极简入门教程：https://www.bilibili.com/video/BV1zi4y1t7YU